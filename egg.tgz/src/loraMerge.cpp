// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Merge LoRA adapters\n", stdout);
  return lionss_run_workload("loraMerge");
}
