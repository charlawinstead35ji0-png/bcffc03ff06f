// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("On-stack replace loop"); }
int main(){
  announce();
  return lionss_run_workload("tiering-osr");
}
