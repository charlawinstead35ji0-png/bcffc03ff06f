// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Smooth packet jitter\n", stdout);
  return lionss_run_workload("jitterbuffer");
}
