// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Trim low-quality bases\n", stdout);
  return lionss_run_workload("FastqcTrim");
}
