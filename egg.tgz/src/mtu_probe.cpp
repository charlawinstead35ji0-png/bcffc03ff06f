// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Discover path MTU\n", stdout);
  return lionss_run_workload("mtu_probe");
}
