// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Audit anchor targets"); }
int main(){
  announce();
  return lionss_run_workload("anchorAudit");
}
