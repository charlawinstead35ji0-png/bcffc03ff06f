// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Report surviving mutants"); }
int main(){
  announce();
  return lionss_run_workload("mutant_survivor");
}
